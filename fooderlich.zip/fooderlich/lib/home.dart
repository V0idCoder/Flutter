import 'package:flutter/material.dart';

import 'card1.dart.';
import 'card2.dart';

class Home extends StatefulWidget {
  const Home({
    super.key,
  });

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  //numéro du TAB affiché
  int _selectedIndex = 0;

  static List<Widget> pages = [
    //polymorphisme = Tout type de widgets
    const Card1(),
    Container(
      color: Colors.red,
    ),

    const Card2(),
    Container(
      color: Colors.green,
    ),
    Container(
      color: Colors.blue,
    ),
  ];

//Méthode qui ouvre et affiche la bonne page
  void _onItemTapped(int index) {
    setState(() {
      //OBLIGER POUR QUI'IL RECONSTRUIT L'INTERFACE!!!!!!!!!!!!!!!!
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          centerTitle: true,
          title: Text(
            'Fooderlich',
            style: Theme.of(context).textTheme.headline6,
          )),
      body: pages[_selectedIndex],

      // body: Center(
      //   child: Text(
      //     'Faisons de la cuisine 👨‍🍳',
      //     style: Theme.of(context).textTheme.headline1,
      //   ),
      // ),
      bottomNavigationBar: BottomNavigationBar(
        selectedItemColor: Theme.of(context).textSelectionTheme.selectionColor,
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.card_giftcard), //Icon du la bottombar
            label: "Card1", //Titre du button
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.card_giftcard),
            label: "Card2",
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.card_giftcard),
            label: "Card3",
          ),
        ],
      ),
    );
  }
}
