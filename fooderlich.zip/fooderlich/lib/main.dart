import "package:flutter/material.dart";

import 'fooderlich_theme.dart';

import 'home.dart';

import 'card1.dart';

void main() {
  runApp(const Fooderlich());
}

class Fooderlich extends StatelessWidget {
  const Fooderlich({super.key});

  @override
  Widget build(BuildContext context) {
    // 1 Définir un théme
    final theme =
        FooderlichTheme.dark(); // On demande à food... d'appliquer le théme
    //TODO: 2 Appliquer le widget home
    return MaterialApp(
      debugShowCheckedModeBanner: false, //Virer le debug
      // 3 Ajour le théme
      theme: theme,
      title: 'Fooderlich',

      home: const Home(),
    );
  }
}
